package main

import (
	"github.com/newrelic/infra-integrations-sdk/data/metric"
	"github.com/newrelic/infra-integrations-sdk/integration"

	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"fmt"
	"io/ioutil"
	"net"
	"reflect"
	"strconv"
	"strings"
	"time"

	"github.com/newrelic/infra-integrations-sdk/log"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

const (
	integrationName    = "com.nr.mongodb-ohi"
	integrationVersion = "0.4.10"
)

// New Relic Tag
const NRAttrTag = "nrAttr"

var (
	args argumentList
)

func main() {

	// Create Integration
	i, err := integration.New(integrationName, integrationVersion, integration.Args(&args))
	panicOnErr(err, "", i)

	entity, err := i.Entity(args.MongoHost, args.Namespace)
	fatalIfErr(err, "failed to create remote entity")

	// Add Metric
	if args.All() || args.Metrics {
		populateMetrics(entity)
	}

	panicOnErr(i.Publish(), "", i)
}

func populateMetrics(entity *integration.Entity) (string, error) {

	logIfErr := func(err error, msg string) (error, string) {
		if err != nil {
			log.Error(msg)
		}

		return err, msg
	}

	dialInfo, err := createDialInfo()
	fatalIfErr(err, "failed to create dialInfo")

	//Connect to mongo shell
	session, err := mgo.DialWithInfo(dialInfo)
	fatalIfErr(err, "failed to create Session")

	defer session.Close()
	session.SetMode(mgo.Monotonic, true)

	_, err = createReplSetStat(session.DB("admin"), entity)
	if err != nil {
		log.Info("Failed to collect Replica Set Stat using Admin database")
	}


	databases := strings.Split(args.MongoDb, ",")
	for _, dbs := range databases {

		db := strings.TrimSpace(dbs)
		if len(db) == 0 {
			continue
		}

		dbSession := session.DB(db)
		if dbSession == nil {
			log.Error("Failed to create DB session for database[%s]\n", db)
			continue
		}

		logIfErr(createConnectionPoolStat(dbSession, entity), "failed to collect Connection Pool Stat")
		logIfErr(createServerStatus(dbSession, entity), "failed to collect Server status")
		logIfErr(createDBStat(dbSession, entity), "failed to collect DB  Stat")
	}

	return "", nil
}

func panicOnErr(err error, message string, integration *integration.Integration) {
	if message != "" {
		integration.Logger().Errorf(message)
	}
	if err != nil {
		panic(err)
	}
}

func createDialInfo() (*mgo.DialInfo, error) {
	dialInfo := &mgo.DialInfo{
		Addrs:    []string{args.MongoHost},
		Timeout:  10 * time.Second,
		Database: args.MongoSource,
		Username: args.MongoUser,
		Password: args.MongoPassword,
		Direct:   true,
		FailFast: true}

	useSSL, _ := strconv.ParseBool(args.SSL)
	if !useSSL {
		return dialInfo, nil
	}

	skipVerify, _ := strconv.ParseBool(args.SkipVerify)

	keyFile := args.PemKeyFile
	passphrase := args.Passphrase

	log.Info("Using Private Key file=%s", keyFile)
	keyPemData, err := ioutil.ReadFile(keyFile)
	fatalIfErr(err, "failed to read private key file"+keyFile)

	clientCert, err := parseCertificate(keyPemData, passphrase)
	fatalIfErr(err, "failed to extract Client certificate from PEM file")
	clientCerts := []tls.Certificate{}
	clientCerts = append(clientCerts, clientCert)

	tlsConfig := &tls.Config{
		Certificates:       clientCerts,
		InsecureSkipVerify: skipVerify}

	dialInfo.DialServer = func(addr *mgo.ServerAddr) (net.Conn, error) {
		conn, err := tls.Dial("tcp", addr.String(), tlsConfig)
		fatalIfErr(err, "")
		return conn, err
	}

	return dialInfo, nil
}
func fatalIfErr(err error, msg string) {
	if err != nil {
		log.Error(msg)
		log.Fatal(err)
	}
}

func parseCertificate(bytes []byte, passphrase string) (tls.Certificate, error) {

	var pvtKeyBlock, clientCertBlock *pem.Block

	for {

		block, rest := pem.Decode(bytes)
		if block == nil {
			return tls.Certificate{}, errors.New("Not a valid PEM file")
		}

		if strings.Contains(block.Type, "PRIVATE KEY") {
			pvtKeyBlock = block
		}

		if block.Type == "CERTIFICATE" {
			clientCertBlock = block
		}

		if len(rest) == 0 || (clientCertBlock != nil && pvtKeyBlock != nil) {
			break
		}

		bytes = rest
	}

	if clientCertBlock == nil {
		return tls.Certificate{}, errors.New("No Client Certificate found in PEM key file.")
	}

	if pvtKeyBlock == nil {
		return tls.Certificate{}, errors.New("No Private Key found in PEM key file.")
	}

	if x509.IsEncryptedPEMBlock(pvtKeyBlock) {
		decPem, err := x509.DecryptPEMBlock(pvtKeyBlock, []byte(passphrase))
		if err != nil {
			return tls.Certificate{}, err
		}
		pvtKeyBlock.Bytes = decPem
		delete(pvtKeyBlock.Headers, "Proc-Type")
		delete(pvtKeyBlock.Headers, "DEK-Info")
	}
	cert, err := tls.X509KeyPair(pem.EncodeToMemory(clientCertBlock), pem.EncodeToMemory(pvtKeyBlock))

	return cert, err
}

func createConnectionPoolStat(db *mgo.Database, entity *integration.Entity) (err error) {

	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("Failed in createConnectionPoolStat(): err=%#v", r)
		}
	}()
	//Get connPoolStats: https://docs.mongodb.com/manual/reference/command/connPoolStats/
	connResult := bson.M{}
	if er := db.Run("connPoolStats", &connResult); er != nil {
		log.Error(er.Error())
		return er
	}

	eventType := "MongoConnectionPoolStat"

	nameSpace := metric.Attribute{"host-db", fmt.Sprintf("%s-%s", args.MongoHost, db.Name)}

	ms := entity.NewMetricSet(eventType, nameSpace)
	ms.SetMetric("db.name", db.Name, metric.ATTRIBUTE)

	for k, v := range connResult {
		ms.SetMetric(k, v, metric.GAUGE)
	}

	return nil
}

func createDBStat(db *mgo.Database, entity *integration.Entity) (err error) {

	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("Failed in createDBStat(): err=%#v", r)
		}
	}()
	eventType := "MongoDBStat"

	nameSpace := metric.Attribute{"host-db", fmt.Sprintf("%s-%s", args.MongoHost, db.Name)}
	ms3 := entity.NewMetricSet(eventType, nameSpace)
	dbStatResult := bson.M{}

	if err := db.Run("dbStats", &dbStatResult); err != nil {
		log.Error(err.Error())
		return err
	}

	ms3.SetMetric("db.name", db.Name, metric.ATTRIBUTE)

	for k, v := range dbStatResult {
		keyName := "dbStat." + k
		ms3.SetMetric(keyName, v, metric.GAUGE)
	}

	return nil
}

func parseNRTag(tag string) (sourceType metric.SourceType, err error) {

	switch tag {
	case "ATTRIBUTE":
		sourceType = metric.ATTRIBUTE
	case "RATE":
		sourceType = metric.RATE
	case "DELTA":
		sourceType = metric.DELTA
	case "GAUGE":
		sourceType = metric.GAUGE
	default:
		return metric.ATTRIBUTE, fmt.Errorf("unknown source type Tag %s", tag)
	}

	return sourceType, nil

}

func parseMetricData(data reflect.Value, ithField int) (nrData NRMetricAttrib, err error) {

	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("Failed in parseMetricData(): ithField=%d data=%#v\n", ithField, data)
		}
	}()

	key := data.Type().Field(ithField).Name
	attr, _ := parseNRTag(data.Type().Field(ithField).Tag.Get(NRAttrTag))
    val := data.Field(ithField).Interface()

	nrData = NRMetricAttrib{key, val, attr}
	log.Debug("parseMetricData(): nrData=%#v\n", nrData)
	return nrData, nil
}

func parseNestedStruct(parentFieldName string, field reflect.Value) (nrData []NRMetricAttrib, err error) {

	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("Failed in parseNestedStruct(): %#v", r)
		}
	}()

	members := field.NumField()
	log.Debug("parseNestedStruct() currFieldName=%s numField=%d", parentFieldName, members)

	for ii := 0; ii < members; ii++ {

		kind := field.Field(ii).Kind()
        isTimeVal := isTimeType(field.Field(ii))
		memberFieldName := field.Type().Field(ii).Name

		// log.Info("-->parseNestedStruct() memberFieldName=%s %s", memberFieldName, isTimeVal)


		if kind == reflect.Struct  {

		    if isTimeVal{
                // handle the time.Time struct
		        tval:= field.Field(ii).Interface().(time.Time).UnixNano()
		        // optimedate is in nanosecond
		        nrData= append( nrData, NRMetricAttrib{  "member."+memberFieldName, tval, metric.GAUGE})
		        continue
            }

			// walk nested struct
			dataArr, _ := parseNestedStruct(memberFieldName, field.Field(ii))
			for idx, mdata := range dataArr {
				dataArr[idx].Name = fmt.Sprintf("%s.%s", parentFieldName, mdata.Name)
			}
			nrData = append(nrData, dataArr...)

		} else {

			data, _ := parseMetricData(field, ii)
			metricNameSpace := fmt.Sprintf("%s.%s", parentFieldName, data.Name)
			data.Name = metricNameSpace
			nrData = append(nrData, data)
		}

	}

	return nrData, nil
}

func createServerStatus(db *mgo.Database, entity *integration.Entity) (err error) {
	statResult := ServerStatus{}

	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("Failed in createServerStatus(): Using Database [%s] Uncaught error: %+v\ncreateServerStatus(): statResult=\"%#v\"\n", db.Name, r, statResult)
			log.Error(err.Error())
		}
	}()

	if err := db.Run("serverStatus", &statResult); err != nil {
		return err
	}

	eventType := "MongoServerStatus"
	nameSpace := metric.Attribute{"host-db", fmt.Sprintf("%s-%s", args.MongoHost, db.Name)}

	metricSet := entity.NewMetricSet(eventType, nameSpace)
	metricSet.SetMetric("db.name", db.Name, metric.ATTRIBUTE)

	stats := reflect.ValueOf(&statResult).Elem()
	nrData := []NRMetricAttrib{}
	for i := 0; i < stats.NumField(); i++ {
		kind := stats.Field(i).Kind()
		fieldName := stats.Type().Field(i).Name

		log.Debug("FieldName=%s isStruct=%b", fieldName, kind == reflect.Struct)

		if kind == reflect.Struct {
			dataArr, _ := parseNestedStruct(fieldName, stats.Field(i))
			nrData = append(nrData, dataArr...)
		} else {
			dataArr, _ := parseMetricData(stats, i)
			nrData = append(nrData, dataArr)
		}

	}

	for _, data := range nrData {
		metricSet.SetMetric(trimAndToLower(data.Name), data.Value, data.MetricSource)
	}

	return nil
}

const NOT_RUNNING_WITH_REPLICA string = "not running with --replSet"

func createReplSetStat(db *mgo.Database, entity *integration.Entity) (isReplicaEnabled bool, err error) {

	var statResult ReplicaSet
	isReplicaEnabled = false

	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("Failed in createReplSetStat(): Using Database [%s] Uncaught error: %+v\ncreateReplSetStat(): statResult=\"%#v\"\n", db.Name, r, statResult)
			log.Error(err.Error())
		}
	}()

	if err := db.Run("replSetGetStatus", &statResult); err != nil {

		if strings.Contains(err.Error(), NOT_RUNNING_WITH_REPLICA) {
			log.Info("Skipping replGetStatus %s", NOT_RUNNING_WITH_REPLICA)
			err = nil
		}

		return isReplicaEnabled, err
	}

	isReplicaEnabled = true
	parseReplicaSetResp(db.Name, statResult, entity)

	return isReplicaEnabled, nil
}

func parseReplicaSetResp(dbName string, statResult ReplicaSet, entity *integration.Entity) {

	stats := reflect.ValueOf(&statResult).Elem()

    nrData, members := initReplData(stats)
	replicaSet := getReplicaSetName(nrData)
    // in nanosecond
    primaryOpTimeInt:= initReplMemberData(dbName ,  members, entity, replicaSet )
	primaryOpTime := time.Unix(0, primaryOpTimeInt)

    for ii := 0; ii < len(members); ii++ {

        // don'compute Primary node, it's our reference
        if entity.Metrics[ii].Metrics["member.statestr"] == "PRIMARY"  || entity.Metrics[ii].Metrics["member.optimedate"] == nil{
            continue
        }

        memberOptTimeInt:= int64(entity.Metrics[ii].Metrics["member.optimedate"].(float64))
        memberOpTime := time.Unix(  0, memberOptTimeInt)

        // compute replica lag and convert to Seconds
        lag  := primaryOpTime.Sub(memberOpTime).Seconds()

        entity.Metrics[ii].Metrics["member.lag"] = lag

        log.Debug("primary opTimeDate=%d  , member opTimeDate=%d ,   lag=%d", memberOpTime.Unix(), primaryOpTime.Unix(), lag)

    }
}

func isTimeType(r reflect.Value) bool {
    return r.Type() == reflect.TypeOf(time.Time{})
}

func trimAndToLower(str string) string {
    return strings.ToLower(strings.TrimSpace(str))
}

func getReplicaSetName(nrData  []NRMetricAttrib) NRMetricAttrib {
    replicaSet := NRMetricAttrib{}
    for _, data := range nrData {
        if data.Name != "Set" {
            continue
        }
        replicaSet = NRMetricAttrib{data.Name, data.Value, data.MetricSource}
        break
    }

    return replicaSet
}

func initReplData(stats reflect.Value)(nrData[]NRMetricAttrib,  members [][]NRMetricAttrib){

    for i := 0; i < stats.NumField(); i++ {
        fieldName := stats.Type().Field(i).Name

        log.Debug("FieldName=%s isStruct=%s", fieldName, stats.Field(i).Kind())

        switch stats.Field(i).Kind() {
        case reflect.Struct:
            dataArr, _ := parseNestedStruct(fieldName, stats.Field(i))
            nrData = append(nrData, dataArr...)

        case reflect.Slice:

            if fieldName != "Member" {
                log.Error("Unknown Slice %s Ignoring.", fieldName)
                break
            }

            membersLen := stats.Field(i).Len()
            members = make([][]NRMetricAttrib, membersLen)
            for ii := 0; ii < membersLen; ii++ {
                member := stats.Field(i).Index(ii)
                dataArr, _ := parseNestedStruct(fieldName, member)
                members[ii] = dataArr
            }

        default:
            dataArr, _ := parseMetricData(stats, i)
            nrData = append(nrData, dataArr)
        }
    }

    return nrData, members
}

func initReplMemberData(dbName string,  members [][]NRMetricAttrib, entity *integration.Entity, replicaSet NRMetricAttrib ) (primaryOpTimeInt int64){
    eventType := "MongoReplSet"
    nameSpace := metric.Attribute{"host-db", fmt.Sprintf("%s-%s", args.MongoHost, dbName)}
    primaryOpTimeInt = int64(0)


    isPrimary:= false
    for ii := 0; ii < len(members); ii++ {
        metricSet := entity.NewMetricSet(eventType, nameSpace)

        metricSet.SetMetric("db.name", dbName, metric.ATTRIBUTE)
        metricSet.SetMetric(trimAndToLower(replicaSet.Name), replicaSet.Value, replicaSet.MetricSource)

        for _, data := range members[ii] {
            fieldName := trimAndToLower(data.Name)
            metricSet.SetMetric(fieldName, data.Value, data.MetricSource)

            // create health string metric
            if fieldName == "member.health" {
                healthStr := "Down"
                if data.Value == 1 {
                    healthStr = "Up"
                }
                metricSet.SetMetric("member.healthstr", healthStr, metric.ATTRIBUTE)
            }


            if fieldName == "member.statestr" && data.Value == "PRIMARY" && primaryOpTimeInt == 0  {
                isPrimary=true

            }

            // find the Primary node and it's optimeDate
            if fieldName == "member.optimedate" && isPrimary  {
                // optimedate is in nanosecond
                primaryOpTimeInt = (data.Value).(int64)
                isPrimary=false

            }

        }

        // set default lag time for all members
        metricSet.SetMetric("member.lag", 0, metric.GAUGE)

    }
    return primaryOpTimeInt
}