package main

import (
	sdkArgs "github.com/newrelic/infra-integrations-sdk/args"
	"github.com/newrelic/infra-integrations-sdk/data/metric"
	"time"
)

type argumentList struct {
	sdkArgs.DefaultArgumentList
	MongoHost     string `default:"localhost"`
	Namespace     string `default:"mongo" help:""`
	MongoSource   string `default:"admin" help:"database used to establish credentials and privileges"`
	MongoDb       string `default:"admin" help:"comma separated database(s)  to monitor"`
	SSL           string `default:"false"`
	SkipVerify    string `default:"true" help:"whether a client verifies the server's certificate chain and host name"`
	PemKeyFile    string `help:"PEM file contains Private Key and Certificate"`
	Passphrase    string `help:"Passphrase for decrypting encrypted Private Key"`
	MongoUser     string
	MongoPassword string
}

type NRMetricAttrib struct {
	Name         string
	Value        interface{}
	MetricSource metric.SourceType
}

type ServerStatus struct {
	Host    string `bson:"host"   nrAttr:"ATTRIBUTE"`
	Uptime  int    `bson:"uptime" nrAttr:"GAUGE"`
	Asserts struct {
		Regular   int `bson:"regular"   nrAttr:"RATE"`
		Warning   int `bson:"warning"   nrAttr:"RATE"`
		Msg       int `bson:"msg"       nrAttr:"RATE"`
		Rollovers int `bson:"rollovers" nrAttr:"RATE"`
		User      int `bson:"user"      nrAttr:"RATE"`
	} `bson:"asserts"`

	Opcounters struct {
		Insert  int `bson:"insert"  nrAttr:"RATE"`
		Query   int `bson:"query"   nrAttr:"RATE"`
		Update  int `bson:"update"  nrAttr:"RATE"`
		Delete  int `bson:"delete"  nrAttr:"RATE"`
		Getmore int `bson:"getmore" nrAttr:"RATE"`
		Command int `bson:"command" nrAttr:"RATE"`
	} `bson:"opcounters"`

	Connections struct {
		Current      int `bson:"current"      nrAttr:"GAUGE"`
		Available    int `bson:"available"    nrAttr:"GAUGE"`
		TotalCreated int `bson:"totalCreated" nrAttr:"GAUGE"`
	} `bson:"connections"`

	Metrics struct {
		MetricsCursor struct {
			TimedOut int64 `bson:"timedOut"  nrAttr:"GAUGE"`
		} `bson:"cursor"`

		Commands struct {
			Delete struct {
				Failed int64 `bson:"failed" nrAttr:"RATE"`
				Total  int64 `bson:"total" nrAttr:"RATE"`
			} `bson:"delete"`

			CreateIndexes struct {
				Failed int64 `bson:"failed" nrAttr:"RATE"`
				Total  int64 `bson:"total" nrAttr:"RATE"`
			} `bson:"createIndexes"`

			Count struct {
				Failed int64 `bson:"failed" nrAttr:"RATE"`
				Total  int64 `bson:"total" nrAttr:"RATE"`
			} `bson:"count"`

			Eval struct {
				Failed int64 `bson:"failed" nrAttr:"RATE"`
				Total  int64 `bson:"total" nrAttr:"RATE"`
			} `bson:"eval"`

			FindAndModify struct {
				Failed int64 `bson:"failed" nrAttr:"RATE"`
				Total  int64 `bson:"total" nrAttr:"RATE"`
			} `bson:"findAndModify"`

			Insert struct {
				Failed int64 `bson:"failed" nrAttr:"RATE"`
				Total  int64 `bson:"total" nrAttr:"RATE"`
			} `bson:"insert"`

			Update struct {
				Failed int64 `bson:"failed" nrAttr:"RATE"`
				Total  int64 `bson:"total" nrAttr:"RATE"`
			} `bson:"update"`

			Document struct {
				Deleted  int64 `bson:"deleted" nrAttr:"RATE"`
				Inserted int64 `bson:"inserted" nrAttr:"RATE"`
				Returned int64 `bson:"returned" nrAttr:"RATE"`
				Updated  int64 `bson:"updated" nrAttr:"RATE"`
			} `bson:"document"`

			GetLastError struct {
				WTime struct {
					Num         int `bson:"num" nrAttr:"RATE"`
					TotalMillis int `bson:"totalMillis" nrAttr:"RATE"`
				} `bson:"wtime"`

				WTimeouts int64 `bson:"wtimeouts" nrAttr:"RATE"`
			} `bson:"getLastError"`
		} `bson:"commands"`

		Operation struct {
			ScanAndOrder   int64 `bson:"scanAndOrder" nrAttr:"RATE"`
			WriteConflicts int64 `bson:"writeConflicts" nrAttr:"RATE"`
		} `bson:"operation"`

		QueryExecutor struct {
			Scanned        int64 `bson:"scanned" nrAttr:"RATE"`
			ScannedObjects int64 `bson:"scannedObjects" nrAttr:"RATE"`
		} `bson:"queryExecutor"`

		Repl struct {
			ReplApply struct {
				Ops     int64 `bson:"ops" nrAttr:"GAUGE"`
				Batches struct {
					Num         int `bson:"num" nrAttr:"RATE"`
					TotalMillis int `bson:"totalMillis" nrAttr:"RATE"`
				} `bson:"batches"`
			} `bson:"apply"`
			ReplBuffer struct {
				Count        int64 `bson:"count" nrAttr:"GAUGE"`
				SizeBytes    int64 `bson:"sizeBytes" nrAttr:"GAUGE"`
				MaxSizeBytes int   `bson:"maxSizeBytes" nrAttr:"GAUGE"`
			} `bson:"buffer"`

			ReplNetwork struct {
				GetMores struct {
					Num         int `bson:"num" nrAttr:"RATE"`
					TotalMillis int `bson:"totalMillis" nrAttr:"RATE"`
				} `bson:"getmores"`

				Ops            int64 `bson:"ops" nrAttr:"RATE"`
				ReadersCreated int64 `bson:"readersCreated" nrAttr:"RATE"`
			} `bson:"network"`

			ReplPreload struct {
				Docs struct {
					Num         int `bson:"num" nrAttr:"RATE"`
					TotalMillis int `bson:"totalMillis" nrAttr:"RATE"`
				} `bson:"docs"`

				Indexes struct {
					Num         int `bson:"num" nrAttr:"RATE"`
					TotalMillis int `bson:"totalMillis" nrAttr:"RATE"`
				} `bson:"indexes"`
			} `bson:"preload"`
		} `bson:"repl"`

		Storage struct {
			Freelist struct {
				Search struct {
					BucketExhausted int `bson:"bucketExhausted" nrAttr:"RATE"`
					Requests        int `bson:"requests" nrAttr:"RATE"`
					Scanned         int `bson:"scanned" nrAttr:"RATE"`
				} `bson:"search"`
			} `bson:"freelist"`
		} `bson:"storage"`
	} `bson:"metrics"`

	Extra_Info struct {
		Page_Faults      int `bson:"page_faults" nrAttr:"RATE"`
		Heap_Usage_Bytes int `bson:"heap_usage_bytes" nrAttr:"RATE"`
	} `bson:"extra_info"`

	ActiveClients struct {
		Readers int `bson:"readers" nrAttr:"GAUGE"`
		Writers int `bson:"writers" nrAttr:"GAUGE"`
	} `bson:"activeClients"`

	GlobalLock struct {
		ActiveClients struct {
			Total   int `bson:"Total" nrAttr:"GAUGE"`
			Readers int `bson:"readers" nrAttr:"GAUGE"`
			Writers int `bson:"writers" nrAttr:"GAUGE"`
		} `bson:"activeClients"`

		CurrentQueue struct {
			Total int `bson:"total" nrAttr:"GAUGE"`
		} `bson:"currentQueue"`
	} `bson:"globalLock"`

	StorageEngine struct {
		Name string `bson:"name" nrAttr:"ATTRIBUTE"`
	} `bson:"storageEngine"`

	WiredTigerMetrics
}

type WiredTigerMetrics struct {
	WiredTiger struct {
		Cache struct {
			Tracked_dirty_bytes_in_the_cache int `bson:"tracked dirty bytes in the cache"  nrAttr:"GAUGE"`

			Tracked_bytes_belonging_to_internal_pages_in_the_cache int `bson:"tracked bytes belonging to internal pages in the cache"  nrAttr:"GAUGE"`
			Bytes_currently_in_the_cache                           int `bson:"bytes currently in the cache" nrAttr:"GAUGE"`

			Tracked_bytes_belonging_to_leaf_pages_in_the_cache int `bson:"tracked bytes belonging to leaf pages in the cache" nrAttr:"GAUGE"`

			Maximum_bytes_configured int `bson:"maximum bytes configured" nrAttr:"GAUGE"`

			Tracked_bytes_belonging_to_overflow_pages_in_the_cache int `bson:"tracked bytes belonging to overflow pages in the cache" nrAttr:"GAUGE"`
			Bytes_read_into_cache                                  int `bson:"bytes read into cache" nrAttr:"GAUGE"`
			Bytes_written_from_cache                               int `bson:"bytes written from cache" nrAttr:"GAUGE"`
			Pages_evicted_by_application_threads                   int `bson:"pages evicted by application threads" nrAttr:"GAUGE"`
			Checkpoint_blocked_page_eviction                       int `bson:"checkpoint blocked page eviction" nrAttr:"GAUGE"`

			Unmodified_pages_evicted                     int `bson:"unmodified pages evicted" nrAttr:"GAUGE"`
			Page_split_during_eviction_deepened_the_tree int `bson:"page split during eviction deepened the tree" nrAttr:"GAUGE"`
			Modified_pages_evicted                       int `bson:"modified pages evicted" nrAttr:"GAUGE"`

			Pages_selected_for_eviction_unable_to_be_evicted             int `bson:"pages selected for eviction unable to be evicted" nrAttr:"GAUGE"`
			Pages_evicted_because_they_exceeded_the_in_memory_maximum    int `bson:"pages evicted because they exceeded the in-memory maximum" nrAttr:"GAUGE"`
			Pages_evicted_because_they_had_chains_of_deleted_items_      int `bson:"pages evicted because they had chains of deleted items" nrAttr:"GAUGE"`
			Failed_eviction_of_pages_that_exceeded_the_in_memory_maximum int `bson:"failed eviction of pages that exceeded the in-memory maximum" nrAttr:"GAUGE"`
			Hazard_pointer_blocked_page_eviction                         int `bson:"hazard pointer blocked page eviction" nrAttr:"GAUGE"`
			Internal_pages_evicted                                       int `bson:"internal pages evicted" nrAttr:"GAUGE"`
			Maximum_page_size_at_eviction                                int `bson:"maximum page size at eviction" nrAttr:"GAUGE"`
			Eviction_server_candidate_queue_empty_when_topping_up        int `bson:"eviction server candidate queue empty when topping up" nrAttr:"GAUGE"`
			Eviction_server_candidate_queue_not_empty_when_topping_up    int `bson:"eviction server candidate queue not empty when topping up" nrAttr:"GAUGE"`
			Eviction_server_evicting_pages                               int `bson:"eviction server evicting pages" nrAttr:"GAUGE"`
			Eviction_server_populating_queue_but_not_evicting_pages      int `bson:"eviction server populating queue, but not evicting pages" nrAttr:"GAUGE"`
			Eviction_server_unable_to_reach_eviction_goal                int `bson:"eviction server unable to reach eviction goal" nrAttr:"GAUGE"`
			Internal_pages_split_during_eviction                         int `bson:"internal pages split during eviction" nrAttr:"GAUGE"`
			Leaf_pages_split_during_eviction                             int `bson:"leaf pages split during eviction" nrAttr:"GAUGE"`
			Pages_walked_for_eviction                                    int `bson:"pages walked for eviction" nrAttr:"GAUGE"`
			Eviction_worker_thread_evicting_pages                        int `bson:"eviction worker thread evicting pages" nrAttr:"GAUGE"`
			Memory_page_splits                                           int `bson:"in-memory page splits" nrAttr:"GAUGE"`
			Memory_page_passed_criteria_to_be_split                      int `bson:"in-memory page passed criteria to be split" nrAttr:"GAUGE"`
			Lookaside_table_insert_calls                                 int `bson:"lookaside table insert calls" nrAttr:"GAUGE"`
			Lookaside_table_remove_calls                                 int `bson:"lookaside table remove calls" nrAttr:"GAUGE"`
			Percentage_overhead                                          int `bson:"percentage overhead" nrAttr:"GAUGE"`
			Tracked_dirty_pages_in_the_cache                             int `bson:"tracked dirty pages in the cache" nrAttr:"GAUGE"`
			Pages_currently_held_in_the_cache                            int `bson:"pages currently held in the cache" nrAttr:"GAUGE"`
			Pages_read_into_cache                                        int `bson:"pages read into cache" nrAttr:"GAUGE"`
			Pages_read_into_cache_requiring_lookaside_entries            int `bson:"pages read into cache requiring lookaside entries" nrAttr:"GAUGE"`
			Pages_written_from_cache                                     int `bson:"pages written from cache" nrAttr:"GAUGE"`
			Page_written_requiring_lookaside_records                     int `bson:"page written requiring lookaside records" nrAttr:"GAUGE"`
			Pages_written_requiring_in_memory_restoration                int `bson:"pages written requiring in-memory restoration" nrAttr:"GAUGE"`
		} `bson:"cache"`

		ConcurrentTransactions struct {
			Write struct {
				Out          int `bson:"out" nrAttr:"GAUGE"`
				Available    int `bson:"available" nrAttr:"GAUGE"`
				TotalTickets int `bson:"totalTickets" nrAttr:"GAUGE"`
			} `bson:"write"`
			Read struct {
				Out          int `bson:"out" nrAttr:"GAUGE"`
				Available    int `bson:"available" nrAttr:"GAUGE"`
				TotalTickets int `bson:"totalTickets" nrAttr:"GAUGE"`
			} `bson:"read"`
		} `bson:"concurrentTransactions"`
	} `bson:"wiredTiger"`
}

type ReplicaSet struct {
	Set                     string `bson:"set" nrAttr:"ATTRIBUTE"`
	// MyState                 int    `bson:"myState" nrAttr:"ATTRIBUTE"`
	// Term                    int64  `bson:"term" nrAttr:"GAUGE"`
	// SyncingTo               string `bson:"syncingTo" nrAttr:"ATTRIBUTE"`
	// SyncSourceHost          string `bson:"syncSourceHost" nrAttr:"ATTRIBUTE"`
	// SyncSourceId            int    `bson:"syncSourceId" nrAttr:"GAUGE"`
	// HeartbeatIntervalMillis  int64  `bson:"heartbeatIntervalMillis" nrAttr:"GAUGE"`

	// Each member of the replica set will be it's own event
	Member []struct {
		Id         int       `bson:"_id" nrAttr:"GAUGE"`
		Name       string    `bson:"name" nrAttr:"ATTRIBUTE"`
		Health     int       `bson:"health" nrAttr:"GAUGE"`
		State      int       `bson:"state" nrAttr:"GAUGE"`
		StateStr   string    `bson:"stateStr" nrAttr:"ATTRIBUTE"`
		Uptime     int       `bson:"uptime" nrAttr:"GAUGE"`
		OptimeDate time.Time `bson:"optimeDate" nrAttr:"GAUGE"`

		PingMs         int    `bson:"pingMs" nrAttr:"GAUGE"`
		SyncingTo      string `bson:"syncingTo" nrAttr:"ATTRIBUTE"`
		SyncSourceHost string `bson:"syncSourceHost" nrAttr:"ATTRIBUTE"`
		SyncSourceId   int    `bson:"syncSourceId" nrAttr:"ATTRIBUTE"`
	} `bson:"members"`

}
