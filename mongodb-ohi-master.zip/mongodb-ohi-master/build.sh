#!/bin/bash
rm bin/*

#build for linux64
GOOS=linux GOARCH=amd64 go build -o bin/mongodb-ohi_linux64 src/*.go

#copy all required integration files to bin
cp *.yml bin/
cp install.* bin/
cp README.md bin/
cp dashboard.json bin/

tar czf mongodb-ohi.tgz bin/*
